# Images and Graphics
  
All images are copyright Medmatix Analytics and David York unless explicitly credited here to another source. Licensing is under the MIT License unless otherwise stated.
